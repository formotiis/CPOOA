/********************************************************************************
** Form generated from reading UI file 'menuenseignant.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENUENSEIGNANT_H
#define UI_MENUENSEIGNANT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MenuEnseignant
{
public:
    QLabel *label_2;
    QPushButton *b_depot;
    QPushButton *b_devoir;
    QPushButton *b_addcours;
    QLabel *label;
    QPushButton *b_deco;
    QLabel *label_3;
    QLabel *label_6;
    QLabel *label_4;

    void setupUi(QWidget *MenuEnseignant)
    {
        if (MenuEnseignant->objectName().isEmpty())
            MenuEnseignant->setObjectName(QStringLiteral("MenuEnseignant"));
        MenuEnseignant->resize(714, 511);
        label_2 = new QLabel(MenuEnseignant);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(150, 120, 371, 61));
        QFont font;
        font.setPointSize(15);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        b_depot = new QPushButton(MenuEnseignant);
        b_depot->setObjectName(QStringLiteral("b_depot"));
        b_depot->setGeometry(QRect(20, 220, 99, 41));
        b_devoir = new QPushButton(MenuEnseignant);
        b_devoir->setObjectName(QStringLiteral("b_devoir"));
        b_devoir->setGeometry(QRect(20, 320, 99, 27));
        b_addcours = new QPushButton(MenuEnseignant);
        b_addcours->setObjectName(QStringLiteral("b_addcours"));
        b_addcours->setGeometry(QRect(20, 120, 99, 27));
        label = new QLabel(MenuEnseignant);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 40, 241, 41));
        QFont font1;
        font1.setPointSize(22);
        label->setFont(font1);
        b_deco = new QPushButton(MenuEnseignant);
        b_deco->setObjectName(QStringLiteral("b_deco"));
        b_deco->setGeometry(QRect(560, 450, 141, 31));
        QFont font2;
        font2.setPointSize(13);
        b_deco->setFont(font2);
        b_deco->setCursor(QCursor(Qt::PointingHandCursor));
        label_3 = new QLabel(MenuEnseignant);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(150, 280, 67, 17));
        label_6 = new QLabel(MenuEnseignant);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(150, 220, 311, 61));
        label_6->setFont(font);
        label_6->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_4 = new QLabel(MenuEnseignant);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(140, 320, 371, 61));
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        retranslateUi(MenuEnseignant);

        QMetaObject::connectSlotsByName(MenuEnseignant);
    } // setupUi

    void retranslateUi(QWidget *MenuEnseignant)
    {
        MenuEnseignant->setWindowTitle(QApplication::translate("MenuEnseignant", "Form", 0));
        label_2->setText(QApplication::translate("MenuEnseignant", "Ajouter un cours, qui sera soumis \303\240 un \n"
"administrateur pour approbation", 0));
        b_depot->setText(QApplication::translate("MenuEnseignant", "Depot\n"
"Ressource", 0));
        b_devoir->setText(QApplication::translate("MenuEnseignant", "Devoirs", 0));
        b_addcours->setText(QApplication::translate("MenuEnseignant", "Ajouter Cours", 0));
        label->setText(QApplication::translate("MenuEnseignant", "Menu Enseignant", 0));
        b_deco->setText(QApplication::translate("MenuEnseignant", "DECONNEXION", 0));
        label_3->setText(QString());
        label_6->setText(QApplication::translate("MenuEnseignant", "Ajouter des ressources \303\240 un cours\n"
" approuv\303\251.", 0));
        label_4->setText(QApplication::translate("MenuEnseignant", "Consulter les devoirs des Etudiants. \n"
" Les noter est aussi une possiblit\303\251.\n"
"", 0));
    } // retranslateUi

};

namespace Ui {
    class MenuEnseignant: public Ui_MenuEnseignant {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENUENSEIGNANT_H
