#include "mainwindow.h"
#include <QApplication>
#include "admin.h"
#include "etudiant.h"
#include "enseignant.h"
#include "modele.h"
#include <stdio.h>
#include <string.h>
#include <iostream>

int main(int argc, char *argv[])
{
    /*
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();*/

    Modele *mod = new Modele();
    mod->inscription("Jaques", "papi306");
    mod->connexion("Jaques", "papi306");
    Personne *c = mod->getConnect();
    std::cout << "Pseudo: " << c->getPseudo() << "\nMotDePasse: " << c->getMDP() << "\nType: " << c->getType() << "\n";
    mod->inscription("Jaques", "papi666");
    mod->deconnexion();
    if (mod->getConnect()== NULL){
        std::cout << "Utilisateur Deconnecté\n";
    }
    mod->~Modele();

}
