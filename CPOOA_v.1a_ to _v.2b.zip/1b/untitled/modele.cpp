#include "modele.h"

Modele::Modele()
{
    personneConnecte = NULL;
}

Modele::~Modele(){
    for(int i = 0; i < listeUtilisateur.size();i++)
        delete listeUtilisateur.at(i);
}

void Modele::deconnexion(){
    personneConnecte = NULL;
}

bool Modele::connexion(std::string identifiant, std::string password){
    bool res = false;
    for(int i =0;i<listeUtilisateur.size();i++){
        if(identifiant.compare(listeUtilisateur.at(i)->getPseudo())==0 && password.compare(listeUtilisateur.at(i)->getMDP())==0){
            personneConnecte = listeUtilisateur.at(i);
            res = true;
        }
    }

    return res;
}

bool Modele::exist(std::string identifiant){
    bool res = false;
    for(int i = 0; i < listeUtilisateur.size();i++)
        if(listeUtilisateur.at(i)->getPseudo().compare(identifiant) == 0)
            res = true;
    return res;
}

void Modele::inscription(std::string identifiant, std::string password){
    if(!Modele::exist(identifiant)){
        listeUtilisateur.push_back(new Etudiant(identifiant, password));
        std::cout << "Inscription réussie\n";
    }
    else {
        std::cout << "Echec : Pseudo déjà existant\n";
    }
}

Personne* Modele::getConnect(){
    return personneConnecte;
}
