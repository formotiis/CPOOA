/********************************************************************************
** Form generated from reading UI file 'menuacceptcours.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENUACCEPTCOURS_H
#define UI_MENUACCEPTCOURS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MenuAcceptCours
{
public:
    QLabel *label_4;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QComboBox *cb_l_cours;
    QLabel *l_npcours;
    QLabel *l_nhcours;
    QLabel *label_5;
    QLabel *l_desc;
    QPushButton *b_accept;
    QPushButton *b_refuse;
    QPushButton *b_cancel;
    QDateEdit *d_debut;
    QDateEdit *d_fin;
    QLabel *label_6;
    QLabel *label_7;

    void setupUi(QWidget *MenuAcceptCours)
    {
        if (MenuAcceptCours->objectName().isEmpty())
            MenuAcceptCours->setObjectName(QStringLiteral("MenuAcceptCours"));
        MenuAcceptCours->resize(1024, 417);
        label_4 = new QLabel(MenuAcceptCours);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(470, 20, 91, 17));
        label = new QLabel(MenuAcceptCours);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 10, 431, 41));
        QFont font;
        font.setPointSize(22);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(MenuAcceptCours);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 150, 211, 21));
        label_2 = new QLabel(MenuAcceptCours);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 130, 211, 17));
        cb_l_cours = new QComboBox(MenuAcceptCours);
        cb_l_cours->setObjectName(QStringLiteral("cb_l_cours"));
        cb_l_cours->setGeometry(QRect(220, 100, 131, 27));
        l_npcours = new QLabel(MenuAcceptCours);
        l_npcours->setObjectName(QStringLiteral("l_npcours"));
        l_npcours->setGeometry(QRect(240, 150, 67, 17));
        l_nhcours = new QLabel(MenuAcceptCours);
        l_nhcours->setObjectName(QStringLiteral("l_nhcours"));
        l_nhcours->setGeometry(QRect(240, 130, 67, 17));
        label_5 = new QLabel(MenuAcceptCours);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(30, 100, 181, 17));
        l_desc = new QLabel(MenuAcceptCours);
        l_desc->setObjectName(QStringLiteral("l_desc"));
        l_desc->setGeometry(QRect(480, 50, 501, 351));
        l_desc->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        b_accept = new QPushButton(MenuAcceptCours);
        b_accept->setObjectName(QStringLiteral("b_accept"));
        b_accept->setGeometry(QRect(30, 280, 99, 27));
        b_refuse = new QPushButton(MenuAcceptCours);
        b_refuse->setObjectName(QStringLiteral("b_refuse"));
        b_refuse->setGeometry(QRect(170, 280, 99, 27));
        b_cancel = new QPushButton(MenuAcceptCours);
        b_cancel->setObjectName(QStringLiteral("b_cancel"));
        b_cancel->setGeometry(QRect(30, 360, 99, 27));
        d_debut = new QDateEdit(MenuAcceptCours);
        d_debut->setObjectName(QStringLiteral("d_debut"));
        d_debut->setGeometry(QRect(210, 180, 111, 27));
        d_fin = new QDateEdit(MenuAcceptCours);
        d_fin->setObjectName(QStringLiteral("d_fin"));
        d_fin->setGeometry(QRect(210, 220, 111, 27));
        label_6 = new QLabel(MenuAcceptCours);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(80, 180, 121, 20));
        label_7 = new QLabel(MenuAcceptCours);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(100, 220, 121, 20));

        retranslateUi(MenuAcceptCours);

        QMetaObject::connectSlotsByName(MenuAcceptCours);
    } // setupUi

    void retranslateUi(QWidget *MenuAcceptCours)
    {
        MenuAcceptCours->setWindowTitle(QApplication::translate("MenuAcceptCours", "Form", 0));
        label_4->setText(QApplication::translate("MenuAcceptCours", "Decription:", 0));
        label->setText(QApplication::translate("MenuAcceptCours", "Acceptation de Cours", 0));
        label_3->setText(QApplication::translate("MenuAcceptCours", "Nombre de places du cours :", 0));
        label_2->setText(QApplication::translate("MenuAcceptCours", "Nombre d'heures du cours :", 0));
        l_npcours->setText(QApplication::translate("MenuAcceptCours", "<number>", 0));
        l_nhcours->setText(QApplication::translate("MenuAcceptCours", "<number>", 0));
        label_5->setText(QApplication::translate("MenuAcceptCours", "Liste des cours \303\240 accepter :", 0));
        l_desc->setText(QApplication::translate("MenuAcceptCours", "<desc>", 0));
        b_accept->setText(QApplication::translate("MenuAcceptCours", "Accepter", 0));
        b_refuse->setText(QApplication::translate("MenuAcceptCours", "Refuser", 0));
        b_cancel->setText(QApplication::translate("MenuAcceptCours", "Retour", 0));
        label_6->setText(QApplication::translate("MenuAcceptCours", "Date de d\303\251but:", 0));
        label_7->setText(QApplication::translate("MenuAcceptCours", "Date de fin:", 0));
    } // retranslateUi

};

namespace Ui {
    class MenuAcceptCours: public Ui_MenuAcceptCours {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENUACCEPTCOURS_H
