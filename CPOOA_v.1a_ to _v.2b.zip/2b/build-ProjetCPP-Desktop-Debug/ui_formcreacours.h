/********************************************************************************
** Form generated from reading UI file 'formcreacours.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMCREACOURS_H
#define UI_FORMCREACOURS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormCreaCours
{
public:
    QLineEdit *f_nhCours;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *f_plCours;
    QLabel *label_4;
    QLineEdit *f_desc;
    QPushButton *b_cancel;

    void setupUi(QWidget *FormCreaCours)
    {
        if (FormCreaCours->objectName().isEmpty())
            FormCreaCours->setObjectName(QStringLiteral("FormCreaCours"));
        FormCreaCours->resize(1024, 417);
        f_nhCours = new QLineEdit(FormCreaCours);
        f_nhCours->setObjectName(QStringLiteral("f_nhCours"));
        f_nhCours->setGeometry(QRect(260, 290, 113, 27));
        label = new QLabel(FormCreaCours);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 431, 41));
        QFont font;
        font.setPointSize(22);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(FormCreaCours);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 290, 211, 17));
        label_3 = new QLabel(FormCreaCours);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 330, 211, 21));
        f_plCours = new QLineEdit(FormCreaCours);
        f_plCours->setObjectName(QStringLiteral("f_plCours"));
        f_plCours->setGeometry(QRect(260, 330, 113, 27));
        label_4 = new QLabel(FormCreaCours);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(480, 20, 91, 17));
        f_desc = new QLineEdit(FormCreaCours);
        f_desc->setObjectName(QStringLiteral("f_desc"));
        f_desc->setGeometry(QRect(560, 20, 451, 391));
        b_cancel = new QPushButton(FormCreaCours);
        b_cancel->setObjectName(QStringLiteral("b_cancel"));
        b_cancel->setGeometry(QRect(40, 380, 99, 27));

        retranslateUi(FormCreaCours);

        QMetaObject::connectSlotsByName(FormCreaCours);
    } // setupUi

    void retranslateUi(QWidget *FormCreaCours)
    {
        FormCreaCours->setWindowTitle(QApplication::translate("FormCreaCours", "Form", 0));
        label->setText(QApplication::translate("FormCreaCours", "Formulaire de creation de Cours", 0));
        label_2->setText(QApplication::translate("FormCreaCours", "Nombre d'heures du cours :", 0));
        label_3->setText(QApplication::translate("FormCreaCours", "Nombre de places du cours :", 0));
        label_4->setText(QApplication::translate("FormCreaCours", "Decription:", 0));
        b_cancel->setText(QApplication::translate("FormCreaCours", "Annuler", 0));
    } // retranslateUi

};

namespace Ui {
    class FormCreaCours: public Ui_FormCreaCours {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMCREACOURS_H
