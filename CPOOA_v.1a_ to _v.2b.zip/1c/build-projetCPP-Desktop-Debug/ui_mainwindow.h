/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *pageConnexion;
    QGroupBox *grpInscrip;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *inscripButton;
    QLineEdit *inscripIdentifiant;
    QLineEdit *inscripMDP;
    QGroupBox *grpConnexion;
    QLineEdit *connexionIdentifiant;
    QLineEdit *connexionMDP;
    QPushButton *connexionButton;
    QLabel *label_2;
    QLabel *label;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1024, 417);
        pageConnexion = new QWidget(MainWindow);
        pageConnexion->setObjectName(QStringLiteral("pageConnexion"));
        grpInscrip = new QGroupBox(pageConnexion);
        grpInscrip->setObjectName(QStringLiteral("grpInscrip"));
        grpInscrip->setGeometry(QRect(560, 20, 421, 351));
        QFont font;
        font.setPointSize(12);
        grpInscrip->setFont(font);
        label_3 = new QLabel(grpInscrip);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 20, 181, 71));
        QFont font1;
        font1.setPointSize(16);
        label_3->setFont(font1);
        label_4 = new QLabel(grpInscrip);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 160, 181, 71));
        label_4->setFont(font1);
        inscripButton = new QPushButton(grpInscrip);
        inscripButton->setObjectName(QStringLiteral("inscripButton"));
        inscripButton->setGeometry(QRect(10, 300, 231, 31));
        inscripIdentifiant = new QLineEdit(grpInscrip);
        inscripIdentifiant->setObjectName(QStringLiteral("inscripIdentifiant"));
        inscripIdentifiant->setGeometry(QRect(10, 80, 401, 71));
        QFont font2;
        font2.setPointSize(35);
        inscripIdentifiant->setFont(font2);
        inscripMDP = new QLineEdit(grpInscrip);
        inscripMDP->setObjectName(QStringLiteral("inscripMDP"));
        inscripMDP->setGeometry(QRect(10, 220, 401, 71));
        inscripMDP->setFont(font2);
        inscripMDP->setEchoMode(QLineEdit::Password);
        grpConnexion = new QGroupBox(pageConnexion);
        grpConnexion->setObjectName(QStringLiteral("grpConnexion"));
        grpConnexion->setGeometry(QRect(50, 20, 491, 361));
        grpConnexion->setFont(font);
        connexionIdentifiant = new QLineEdit(grpConnexion);
        connexionIdentifiant->setObjectName(QStringLiteral("connexionIdentifiant"));
        connexionIdentifiant->setGeometry(QRect(10, 80, 471, 71));
        connexionIdentifiant->setFont(font2);
        connexionMDP = new QLineEdit(grpConnexion);
        connexionMDP->setObjectName(QStringLiteral("connexionMDP"));
        connexionMDP->setGeometry(QRect(10, 220, 471, 71));
        connexionMDP->setFont(font2);
        connexionMDP->setEchoMode(QLineEdit::Password);
        connexionButton = new QPushButton(grpConnexion);
        connexionButton->setObjectName(QStringLiteral("connexionButton"));
        connexionButton->setGeometry(QRect(10, 300, 251, 31));
        connexionButton->setFont(font);
        label_2 = new QLabel(grpConnexion);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 20, 181, 71));
        label_2->setFont(font1);
        label = new QLabel(grpConnexion);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 160, 181, 71));
        label->setFont(font1);
        connexionIdentifiant->raise();
        connexionMDP->raise();
        connexionButton->raise();
        label_2->raise();
        label->raise();
        MainWindow->setCentralWidget(pageConnexion);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Projet CPOOA", 0));
        grpInscrip->setTitle(QApplication::translate("MainWindow", "Inscription", 0));
        label_3->setText(QApplication::translate("MainWindow", "Identifiant :", 0));
        label_4->setText(QApplication::translate("MainWindow", "Mot de Passe :", 0));
        inscripButton->setText(QApplication::translate("MainWindow", "Inscription", 0));
        grpConnexion->setTitle(QApplication::translate("MainWindow", "Connexion", 0));
        connexionButton->setText(QApplication::translate("MainWindow", "Connexion", 0));
        label_2->setText(QApplication::translate("MainWindow", "Identifiant :", 0));
        label->setText(QApplication::translate("MainWindow", "Mot de Passe :", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
