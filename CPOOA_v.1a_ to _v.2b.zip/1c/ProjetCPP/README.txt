Projet Cael, Virte :

Etat du projet :

Possibilit� d'inscription et de connexion par lecture d'un fichier .txt de forme :
<pseudo> <mot de passe> <type d'utilisateur>

Les differents types d'utilisateurs sont:
-Etudiant (de base pour toute inscriptions)
-Admin
-Enseignant

Suite du projet : 
Affichage d'un accueil avec des options diff�rentes et fonctions du type, deconnexion et soumissions de
formulaires de cours par les enseignants.
