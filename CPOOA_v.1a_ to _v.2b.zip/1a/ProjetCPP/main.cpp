#include "mainwindow.h"
#include <QApplication>
#include "admin.h"
#include "etudiant.h"
#include "enseignant.h"
#include <stdio.h>
#include <string.h>
#include <iostream>

int main(int argc, char *argv[])
{
    /*
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();*/

    Admin *a = new Admin("Jaques", "papi306");
    std::cout << "Pseudo: " << a->getPseudo() << "\nMotDePasse: " << a->getMDP() << "\nType: " << a->getType() << "\n\n";
    delete a;

    Enseignant *b = new Enseignant("Jaqueline", "mami809");
    std::cout << "Pseudo: " << b->getPseudo() << "\nMotDePasse: " << b->getMDP() << "\nType: " << b->getType() << "\n\n";
    delete b;

    Etudiant *c = new Etudiant("Jaquelin", "zerochill777");
    std::cout << "Pseudo: " << c->getPseudo() << "\nMotDePasse: " << c->getMDP() << "\nType: " << c->getType() << "\n";
    delete c;
}
